
import React from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, Phone, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

const HomePage = () => {
  const contactInfo = [
    {
      icon: MapPin,
      label: 'Address',
      value: 'HAUPTSTR. 28, 65843 SULZBACH / TS',
      href: null
    },
    {
      icon: Phone,
      label: 'Telephone',
      value: '06196 - 999 8220',
      href: 'tel:+496196-9998220'
    },
    {
      icon: Phone,
      label: 'Mobile',
      value: '0175 - 3089 3895',
      href: 'tel:+491753089395'
    },
    {
      icon: Mail,
      label: 'Email',
      value: 'info@dermafirst.de',
      href: 'mailto:info@dermafirst.de'
    }
  ];

  return (
    <>
      <Helmet>
        <title>dermafirst.de - Professional Dermatology Services</title>
        <meta name="description" content="Professional dermatology and skincare services in Berlin. Expert care for your skin health." />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1616391182219-e080b4d1043a" 
              alt="Professional dermatology clinic interior with modern equipment"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/70 to-background/90"></div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 
              className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight"
              style={{ letterSpacing: '-0.02em', textBalance: 'balance' }}
            >
              dermafirst.de
            </h1>
            <p className="text-xl md:text-2xl text-foreground/90 mb-8 max-w-2xl mx-auto leading-relaxed">
              Your trusted partner for professional dermatology and comprehensive skincare services
            </p>
            <Button 
              size="lg" 
              className="text-lg px-8 py-6 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
              asChild
            >
              <a href="#contact">Contact us</a>
            </Button>
          </motion.div>
        </section>

        {/* Contact Details Section */}
        <section id="contact" className="py-20 bg-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 
                className="text-3xl md:text-4xl font-bold text-secondary-foreground mb-4 text-center"
                style={{ textBalance: 'balance' }}
              >
                Get in touch
              </h2>
              <p className="text-lg text-secondary-foreground/80 mb-12 text-center max-w-2xl mx-auto">
                We're here to help with all your dermatology needs
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {contactInfo.map((item, index) => {
                  const Icon = item.icon;
                  const content = (
                    <Card className="h-full transition-all duration-200 hover:shadow-lg">
                      <CardContent className="p-8">
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                            <Icon className="w-6 h-6 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                              {item.label}
                            </h3>
                            <p className="text-lg font-medium text-card-foreground break-words">
                              {item.value}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );

                  return (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      {item.href ? (
                        <a 
                          href={item.href}
                          className="block h-full focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 rounded-2xl transition-all duration-200"
                        >
                          {content}
                        </a>
                      ) : (
                        content
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-background border-t border-border py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <p className="text-sm text-muted-foreground">
                © {new Date().getFullYear()} dermafirst.de. All rights reserved.
              </p>
              <div className="flex items-center gap-6">
                <a 
                  href="#" 
                  className="text-sm text-muted-foreground hover:text-foreground transition-all duration-200"
                >
                  Privacy Policy
                </a>
                <a 
                  href="#" 
                  className="text-sm text-muted-foreground hover:text-foreground transition-all duration-200"
                >
                  Terms of Service
                </a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default HomePage;
